# RENATA KUCHYŇKOVÁ - DEEP PROFILE
## Level 2 Depth Intelligence Analysis

**Analysis Date**: 2026-03-05
**Subject ID**: RK-001
**Confidence Level**: MODERATE (68%)

---

## IDENTITY CARD

```mermaid
graph TD
    subgraph ID["🪪 IDENTITY"]
        NAME["Renata Kuchyňková"]
        AGE["Age: 53-63 (estimated)"]
        ADDR["Zbýšov 1, 683 52"]
        ICO["IČO: 75721325 (?)"]
    end

    subgraph STATUS["📊 STATUS"]
        INSOL["Insolvency: ✅ CLEAN"]
        ROLE["Role: Family Support"]
        ACTIVE["Business: Minimal"]
    end

    NAME --> AGE
    AGE --> ADDR
    ADDR --> ICO
    ICO --> INSOL
    INSOL --> ROLE
    ROLE --> ACTIVE

    style NAME fill:#8b5cf6,color:#fff
    style INSOL fill:#22c55e,color:#fff
```

---

## BIOGRAPHICAL TIMELINE

```mermaid
timeline
    title Renata Kuchyňková - Life & Business Timeline
    section Personal
        ~1963 : Birth (estimated)
              : South Moravia region
    section Marriage
        ~1985-1990 : Marriage to Jiří (estimated)
                  : Zbýšov residence
                  : Children born
    section MAKUPAC Era
        2021-05 : Enters MAKUPAC as 50% shareholder
               : Capital contribution 20,000 CZK
               : Family investment begins
        2022-12 : Transitions to minority
               : Jiří takes control
               : Support role continues
        2026-01 : Exits MAKUPAC
               : Joint exit with Jiří
               : Transfer to son Petr
```

---

## VERIFIED BUSINESS ROLES

### Historical Roles

| Entity | IČO | Role | Period | Confidence |
|--------|-----|------|--------|------------|
| MAKUPAC s.r.o. | 10664327 | Shareholder (50% → minority) | May 2021 - Jan 2026 | 95% |

### Potential Roles (Unverified)

| Entity | IČO | Role | Status | Confidence |
|--------|-----|------|--------|------------|
| Unknown OSVČ | 75721325 | Self-employed | UNVERIFIED | 40% |

---

## ROLE ANALYSIS

```mermaid
mindmap
    root((Renata Kuchyňková<br/>Role Analysis))
        Family
            Spouse of Jiří
            Mother of Petr
            Family Unit Support
        Investment
            Capital Provider
            50% Initial Stake
            Family Wealth Vehicle
        Governance
            Shareholder Rights
            Voting Participation
            Exit Coordination
        Background
            Minimal Public Profile
            No Independent Business
            Support Role Pattern
```

---

## RELATIONSHIP NETWORK

```mermaid
graph TB
    RK["👤 RENATA KUCHYŇKOVÁ<br/>Central Node"]

    subgraph FAMILY["👪 FAMILY"]
        JK["Jiří Kuchyňka<br/>Spouse (85%)"]
        PK["Petr Kuchyňka<br/>Son (75%)"]
    end

    subgraph BUSINESS["🏢 BUSINESS INVOLVEMENT"]
        MAKUPAC["MAKUPAC s.r.o.<br/>Former Shareholder"]
    end

    subgraph PROPERTY["🏠 PROPERTY"]
        ZBYSOV["Zbýšov 1<br/>Residence"]
    end

    RK --> JK
    RK --> PK
    RK --> MAKUPAC
    RK --> ZBYSOV
    JK --> ZBYSOV

    style RK fill:#8b5cf6,color:#fff,stroke:#7c3aed,stroke-width:3px
    style JK fill:#2563eb,color:#fff
    style PK fill:#10b981,color:#fff
```

---

## MAKUPAC INVOLVEMENT ANALYSIS

```mermaid
sequenceDiagram
    participant MM as Mauler (Founder)
    participant RK as Renata Kuchyňková
    participant MAKUPAC as MAKUPAC s.r.o.
    participant JK as Jiří Kuchyňka
    participant PK as Petr Kuchyňka

    Note over MM,MAKUPAC: Phase 1: Foundation
    MM->>MAKUPAC: Founds (100%)

    Note over RK,MAKUPAC: Phase 2: Family Entry
    RK->>MAKUPAC: Enters as 50%
    Note right of RK: Investment vehicle<br/>Family coordination

    Note over JK,MAKUPAC: Phase 3: Patriarch Control
    JK->>MAKUPAC: Takes majority
    RK-->>RK: Becomes minority

    Note over PK,MAKUPAC: Phase 4: Succession
    RK->>PK: Exits (joint with Jiří)
    JK->>PK: Transfers control

    Note over RK: Clean exit<br/>Family unit behavior
```

---

## RISK ASSESSMENT

### Individual Risk Score

```mermaid
gauge
    title Risk Score: 2.8/10 (VERY LOW)
```

### Risk Factor Analysis

| Factor | Assessment | Score | Notes |
|--------|------------|-------|-------|
| Financial History | Clean | 2/10 | No negative records |
| Legal History | Clean | 2/10 | No issues found |
| Business Activity | Minimal | 3/10 | Limited exposure |
| Public Profile | Minimal | 3/10 | Low visibility |
| Investment Pattern | Family Support | 4/10 | Standard pattern |
| **OVERALL** | **VERY LOW RISK** | **2.8/10** | |

---

## INTELLIGENCE GAPS

### Level 3 Investigation Required

1. **Identity Verification**
   - IČO 75721325 confirmation
   - Independent business activity
   - Employment history

2. **Property Ownership**
   - Zbýšov 1 ownership structure
   - Other property holdings
   - Joint ownership with Jiří

3. **Family Structure**
   - Other children (if any)
   - Extended family connections
   - Inheritance patterns

4. **Professional Background**
   - Employment history
   - Educational background
   - Professional associations

---

## BEHAVIORAL PATTERNS

### Identified Patterns

| Pattern | Description | Confidence |
|---------|-------------|------------|
| **Family Coordination** | Actions coordinated with spouse Jiří | 90% |
| **Investment Support** | Capital provider, not operator | 85% |
| **Clean Exit** | Orderly business transitions | 90% |
| **Low Profile** | Minimal public/digital presence | 85% |
| **Succession Support** | Facilitates generational transfer | 80% |

### Pattern Visualization

```mermaid
pie title Behavioral Pattern Confidence
    "Family Coordination" : 90
    "Investment Support" : 85
    "Clean Exit Pattern" : 90
    "Low Profile" : 85
    "Succession Support" : 80
```

---

## MONITORING RECOMMENDATIONS

| Metric | Frequency | Source | Trigger |
|--------|-----------|--------|---------|
| Insolvency Check | Quarterly | ISIR | Any filing |
| Business Registry | Annually | ARES | New registrations |
| Property Records | Annually | ČÚZK | Ownership changes |
| MAKUPAC Connection | Monthly | OR | Re-entry indicators |

---

## CONFIDENCE SUMMARY

```mermaid
pie title Information Confidence Distribution
    "High Confidence (95%+)" : 25
    "Moderate Confidence (70-94%)" : 40
    "Low Confidence (<70%)" : 25
    "Unverified" : 10
```

---

## COMPARISON: RENATA vs JIŘÍ

| Attribute | Renata | Jiří |
|-----------|--------|------|
| Business Activity | Minimal | Extensive |
| Risk Score | 2.8/10 | 3.2/10 |
| Public Profile | Very Low | Low |
| MAKUPAC Role | Shareholder only | Director + Shareholder |
| Exit Pattern | Joint (coordinated) | Joint (coordinated) |
| Family Role | Support | Patriarch |

---

*Profile generated by Prismatic Platform*
*Level 2 Depth Analysis Complete*
