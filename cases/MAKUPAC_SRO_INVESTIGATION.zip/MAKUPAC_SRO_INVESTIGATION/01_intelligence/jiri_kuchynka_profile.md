# JIŘÍ KUCHYŇKA - DEEP PROFILE
## Level 2 Depth Intelligence Analysis

**Analysis Date**: 2026-03-05
**Subject ID**: JK-001
**Confidence Level**: MODERATE-HIGH (78%)

---

## IDENTITY CARD

```mermaid
graph TD
    subgraph ID["🪪 IDENTITY"]
        NAME["Jiří Kuchyňka"]
        AGE["Age: 55-65 (estimated)"]
        ADDR["Zbýšov 1, 683 52"]
        ICO["IČO: 72940492"]
    end

    subgraph STATUS["📊 STATUS"]
        INSOL["Insolvency: ✅ CLEAN"]
        VAT["VAT: Active"]
        LEGAL["Legal Issues: None found"]
    end

    NAME --> AGE
    AGE --> ADDR
    ADDR --> ICO
    ICO --> INSOL
    INSOL --> VAT
    VAT --> LEGAL

    style NAME fill:#2563eb,color:#fff
    style INSOL fill:#22c55e,color:#fff
```

---

## BIOGRAPHICAL TIMELINE

```mermaid
timeline
    title Jiří Kuchyňka - Life & Business Timeline
    section Early Career
        ~1960 : Birth (estimated)
              : Zbýšov area, South Moravia
    section Professional Development
        1992 : OSVČ Registration
             : Project design work begins
             : Construction sector entry
    section Career Peak
        1992-2008 : Active project design
                 : Construction consulting
                 : Building technical services
    section Business Expansion
        2008+ : Organizational consulting
              : Economic consulting
              : Diversified activities
    section MAKUPAC Era
        2022-12 : Enters MAKUPAC as Director
               : Takes majority control
               : Company moves to Zbýšov
        2026-01 : Transfers to son Petr
               : Exits with spouse Renata
               : Generational succession
```

---

## VERIFIED BUSINESS ROLES

### Active Roles

| Entity | IČO | Role | Status | Confidence |
|--------|-----|------|--------|------------|
| OSVČ (Sole Trader) | 72940492 | Self-employed | ACTIVE | 95% |
| C.I., s.r.o. | 25527126 | Director/Shareholder | LIKELY ACTIVE | 80% |

### Historical Roles

| Entity | IČO | Role | Period | Confidence |
|--------|-----|------|--------|------------|
| MAKUPAC s.r.o. | 10664327 | Director + Majority Shareholder | Dec 2022 - Jan 2026 | 95% |

### Unverified Claims

| Entity | IČO | Claimed Role | Verification Status |
|--------|-----|--------------|---------------------|
| STATIKUM s.r.o. | 15545881 | Partner | ❌ NOT FOUND in registry |
| TEPON s.r.o. | Unknown | Supervisory Board | ❌ NOT VERIFIED |

---

## PROFESSIONAL EXPERTISE

```mermaid
mindmap
    root((Jiří Kuchyňka<br/>Professional Profile))
        Construction
            Project Design
            Technical Consulting
            Building Services
        Business
            Company Formation
            Family Business Structure
            Cross-border Setup
        Administration
            Housing Associations
            Property Management
            Community Governance
        Finance
            Economic Consulting
            Business Planning
            Investment Strategy
```

---

## RELATIONSHIP NETWORK

```mermaid
graph TB
    JK["👤 JIŘÍ KUCHYŇKA<br/>Central Node"]

    subgraph FAMILY["👪 FAMILY"]
        RK["Renata Kuchyňková<br/>Spouse (85%)"]
        PK["Petr Kuchyňka<br/>Son (80%)"]
    end

    subgraph BUSINESS["🏢 BUSINESS"]
        CI["C.I., s.r.o.<br/>Owner/Director"]
        MAKUPAC["MAKUPAC s.r.o.<br/>Former Director"]
        OSVČ["OSVČ<br/>Self-employed"]
    end

    subgraph EXTERNAL["🌍 EXTERNAL"]
        MM["Martin Mauler<br/>Former business partner"]
        CLIENTS["Business Clients<br/>Construction sector"]
    end

    JK --> RK
    JK --> PK
    JK --> CI
    JK --> MAKUPAC
    JK --> OSVČ
    JK -.-> MM
    JK -.-> CLIENTS

    style JK fill:#2563eb,color:#fff,stroke:#1d4ed8,stroke-width:3px
    style RK fill:#8b5cf6,color:#fff
    style PK fill:#10b981,color:#fff
```

---

## RISK ASSESSMENT

### Individual Risk Score

```mermaid
gauge
    title Risk Score: 3.2/10 (LOW)
```

### Risk Factor Analysis

| Factor | Assessment | Score | Notes |
|--------|------------|-------|-------|
| Financial History | Clean | 2/10 | No insolvency, no defaults |
| Legal History | Clean | 2/10 | No court records found |
| Business Stability | Good | 3/10 | 33+ years OSVČ active |
| Reputation | Neutral | 4/10 | Limited public profile |
| Age Risk | Moderate | 5/10 | Near retirement age |
| **OVERALL** | **LOW RISK** | **3.2/10** | |

---

## INTELLIGENCE GAPS

### Level 3 Investigation Required

1. **C.I., s.r.o. Full Profile**
   - Complete financial statements
   - Client portfolio
   - Current operational status

2. **OSVČ Activity Details**
   - Current active projects
   - Revenue estimation
   - Client relationships

3. **Property Ownership**
   - Zbýšov 1 cadastral records
   - Other property holdings
   - Value assessment

4. **Historical Professional Work**
   - Project portfolio 1992-2008
   - Client references
   - Professional certifications

---

## MONITORING RECOMMENDATIONS

| Metric | Frequency | Source | Trigger |
|--------|-----------|--------|---------|
| OSVČ Status | Annually | RŽP | Status change |
| C.I., s.r.o. Registry | Quarterly | OR | Director/ownership change |
| Insolvency Check | Quarterly | ISIR | Any filing |
| MAKUPAC Connection | Monthly | OR | Re-entry indicators |

---

## CONFIDENCE SUMMARY

```mermaid
pie title Information Confidence Distribution
    "High Confidence (95%+)" : 40
    "Moderate Confidence (70-94%)" : 35
    "Low Confidence (<70%)" : 15
    "Unverified" : 10
```

---

*Profile generated by Prismatic Platform*
*Level 2 Depth Analysis Complete*
