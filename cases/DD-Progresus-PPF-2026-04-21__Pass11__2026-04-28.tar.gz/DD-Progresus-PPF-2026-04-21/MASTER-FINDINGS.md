# Master Zjištění — DD Progresus

**Poslední aktualizace**: 2026-04-21
**Celkem zjištění**: 25 (7 KRITICKÝCH + 11 VYSOKÝCH + 7 STŘEDNÍCH) — z přehledu 2026-04-01, probíhá ověřování

Legenda: `OPEN` = nevyřešeno | `DISC` = zveřejněno v DD místnosti | `MITG` = probíhá zmírnění | `RSLV` = vyřešeno

---

## KRITICKÉ (7)

| # | Zjištění | Důkaz | Stav | Riziko PPF | Obrana |
|---|---------|----------|--------|----------|---------|
| C1 | **Nesrovnalost CASPER: 800M CZK v dok. A vs. 229M CZK v dok. B** | Křížová reference dokumentů z přehledu 2026-04-01 (DB prázdná, nutno znovu načíst) | OPEN | Tvrzení o zkreslení → porušení prohlášení a záruky → uplatnění odškodnění | Sjednotit: která hodnota je účetní vs. fair value vs. zástavní hodnota? Znovu načíst dokumenty. |
| C2 | **Skrytá / nezveřejněná entita RONDAX ve struktuře skupiny** | Křížová diference dokumentů 2026-04-01 | OPEN | Nezveřejněná dceřiná společnost → manipulace s UBO, daňová strukturace, skryté závazky | Ověřit ARES + OR; pokud aktivní, zveřejnit s odůvodněním; pokud spící, zdokumentovat ukončení |
| C3 | **Agregátní dluh skupiny cca 1 mld. CZK** | Křížová reference finančních dokumentů 2026-04-01 | OPEN | Kaskáda křížového selhání; spouštěče covenantů při změně kontroly | Zmapovat každý úvěr/dluhopis; identifikovat doložky CoC; předjednat výjimky; předložit refinanční plán |
| C4 | **DANCORE LLC Nevada — 6letý živý spor o NZ pozemky (spis 30 Co 228/2019-1538)** [AKTUALIZOVÁNO 2026-04-21] | Dluhopisový prospekt 2024-12-30; Justia/Law360 potvrzují paralelní Dancore v. Zika 2:18-cv-01136 (D.Nev); Prismatic forenzní složka | OPEN | Riziko titulu na 1,1 mil. m² NZ pozemků; odvolání podáno 2024-11-18 ŽIVÉ; NENÍ res judicata; forenzní složka očekávaná hodnota CZK 102,5M / nepravděpodobná škoda CZK 1,0 mld. | **Úschova CZK 250–400M + pojištění titulu vynětí DANCORE + W&I**; plná forenzní složka v `04-legal/DANCORE-FORENSIC-DOSSIER.md` |
| C5 | **4 právní řízení vykázána jako 1** | Dok. vs. soupis sporů 2026-04-01 | OPEN | Materiální zatajení → porušení prohlášení a záruky; může zrušit transakci | Kompletní soupis sporů: č. spisu, soud, žalobce, výše nároku, stav, rezervy |
| C6 | **HP (Hospodářské Pozemky?) — zákaz sdílení/spolu­obývání** | Záznamy povolování / obce 2026-04-01 | OPEN | Omezení použitelnosti aktiva → přímý dopad na ocenění | Právní stanovisko k rozsahu; plán přezónování; alternativní využití |
| C7 | **Studio Perspektiv — „3. místo, ne vítěz" tendru** | Tendrová dokumentace vs. marketingové tvrzení 2026-04-01 | OPEN | Spor o IP / smluvní; reputační riziko; možná chybějící licence designu | Tendrové záznamy obce; smluvní řetězec k aktuálnímu designu; potvrzení licence |

## VYSOKÉ (11)

| # | Zjištění | Stav | Riziko PPF | Obrana |
|---|---------|--------|----------|---------|
| H1 | Nesrovnalosti dluhopisového prospektu (Progresus Invest) | OPEN | Porušení informační povinnosti vůči ČNB, nároky držitelů dluhopisů | Sladění podání u ČNB |
| H2 | Stav územního plánu / stavebního povolení pro Nový Zeleneč | OPEN | Riziko fázového povolování, prodleva monetizace | Matice aktuálního stavu, právní stanovisko k harmonogramům |
| H3 | Závislost na klíčové osobě JUDr. Lukáše Zrůsta | OPEN | Faktor klíčové osoby, riziko přechodu | Plán nástupnictví, retenční struktura, konkurenční doložka |
| H4 | Půjčky mezi spřízněnými stranami v rámci skupiny | OPEN | Transferové ceny, skrytá podřízenost | Mapa vnitroskupinových úvěrů, metodika cen |
| H5 | Zatížení LV 927 + LV 1326 (katastr) | OPEN | Zástavy, věcná břemena na klíčových pozemcích | Plné výpisy LV, plán vymazání zatížení |
| H6 | Postoj obce Zeleneč — politické sladění | OPEN | Riziko zablokování povolení po převodu | Mapa stakeholderů, nedávná rozhodnutí zastupitelstva |
| H7 | Historické environmentální závazky na 42 ha | OPEN | CERCLA-typ české expozice za sanaci | Stav ESIA, posouzení zeminy/podzemní vody |
| H8 | Doložky dluhopisů ohledně změny kontroly | OPEN | Spuštění prodejního práva, refinanční tlak | Doložková analýza prospektů |
| H9 | Ocenění výroby/zásob RD Rýmařov | OPEN | Alokace protiplnění při sloučení | Samostatné ocenění, oddělit při majetkovém obchodu |
| H10 | Daňová expozice — transferové ceny, řetězce DPH | OPEN | Víceleté zpětné daňové nároky | Daňová memo, dokumentace TP |
| H11 | Koncentrace protistran (klíčoví dodavatelé/odběratelé) | OPEN | Provozní šok po uzavření | Top-10 protistran, smluvní podmínky |

## STŘEDNÍ (7)

| # | Zjištění | Stav | Riziko PPF | Obrana |
|---|---------|--------|----------|---------|
| M1 | Soulad GDPR v DD dataroomu | OPEN | Nízké, ale standardní DD požadavek | DPIA, smlouvy o zpracování |
| M2 | Standardizace pracovních smluv | OPEN | Riziko retence | Audit standardních smluv |
| M3 | Řetězec přiřazení IP (loga, marketingové materiály) | OPEN | Nízké riziko IP | Smlouvy o postoupení IP |
| M4 | Adekvátnost pojistného krytí (D&O, majetek) | OPEN | Mezera po uzavření | Rozpis pojištění + plán prodloužení |
| M5 | Soulad s dotacemi (EU fondy) | OPEN | Riziko zpětného vymáhání při zneužití | Rozpis dotací + osvědčení o souladu |
| M6 | Struktury odměňování představenstva / vedení | OPEN | Výplaty při změně kontroly | Rozpis odměňování |
| M7 | Stav kybernetické bezpečnosti | OPEN | Únik dat po uzavření | Report penetračního testu, bezpečnostní směrnice |

---

## Souhrn stavu

- **OPEN**: 25 / 25 (100 %)
- **ZVEŘEJNĚNO**: 0
- **ZMÍRNĚNO**: 0
- **VYŘEŠENO**: 0

**DALŠÍ KROK**: Vyřešit blokátor načítání dat (prázdná SQLite DB) k opětovnému ověření zjištění z 2026-04-01 vůči zdrojovým dokumentům.

<!-- BACKLINKS_START -->

---

## 🔗 Zpětné odkazy

Na tento soubor odkazují:

- [CHANGELOG.md](./CHANGELOG.md) — MASTER-FINDINGS.md (2×)
- [LINK-AUDIT.md](./LINK-AUDIT.md) — MASTER-FINDINGS.md (2×)
- [WORKSPACE-STATS.md](./WORKSPACE-STATS.md) — MASTER-FINDINGS.md (2×)
- [_assets/CANVAS-AUDIT.md](./_assets/CANVAS-AUDIT.md) — MASTER-FINDINGS.md (2×)
- [01-intel/README.md](./01-intel/README.md) — MASTER-FINDINGS.md
- [02-entity/README.md](./02-entity/README.md) — MASTER-FINDINGS.md
- [04-legal/README.md](./04-legal/README.md) — MASTER-FINDINGS.md
- [07-sources/README.md](./07-sources/README.md) — MASTER-FINDINGS.md

## 🏷️ Související soubory (podle shody tagů)

- [LINK-AUDIT.md](./LINK-AUDIT.md) — podobnost 0.40 · AUDIT ODKAZŮ
- [_assets/CANVAS-AUDIT.md](./_assets/CANVAS-AUDIT.md) — podobnost 0.33 · Audit rozměrů canvas / grafů / map
- [WORKSPACE-STATS.md](./WORKSPACE-STATS.md) — podobnost 0.31 · Statistiky pracovního prostoru — DD-Progresus-PPF-2026-04-21
- [07-sources/README.md](./07-sources/README.md) — podobnost 0.31 · 07-sources — Manifest důkazů a řetězec původu
- [01-intel/README.md](./01-intel/README.md) — podobnost 0.31 · 01-intel — Kontext transakce, stakeholdeři, komunikace

## 🌐 Pohled grafu

[Otevřít v portálu](./index.html) · [Mapa stránek](./sitemap.html) · [Hledat](./search.html) · Focus ID: `MASTER-FINDINGS.md`

---
*Automaticky vygenerováno skriptem `_assets/build-backlinks.py` · 2026-04-21*
<!-- BACKLINKS_END -->
