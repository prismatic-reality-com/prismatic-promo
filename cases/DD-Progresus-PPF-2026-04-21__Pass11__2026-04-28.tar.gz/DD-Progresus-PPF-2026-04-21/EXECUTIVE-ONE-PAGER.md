# MANAŽERSKÝ PŘEHLED — PROJEKT MYCELIUM

**Progresus → PPF | Nový Zeleneč 42 ha | Cílová cena 5–6 mld. CZK | Minimální cena 3,7 mld. | Kotva 6,5 mld.**


Klasifikace: POUZE PRO TÝM PRODÁVAJÍCÍHO | Verze 1.0 | 2026-04-21 | Podkladový list pro JUDr. Zrůsta

---

## 5 KLÍČOVÝCH FAKT (k zapamatování)

1. **Cílová společnost**: Nový Zeleneč a.s. (IČO 27825981), 100% vlastněná RD Rýmařov Invest III. alpha s.r.o. (IČO 10800123). Struktura: **akciový obchod na III. alpha** (zachovává ÚP + EIA + plánovací smlouvu).
2. **Aktivum**: 42 ha souvislého greenfieldu, k.ú. Mstětice **kód 792764** (NIKOLI 693685). Pravděpodobné parcely **73/1 (24,85 ha) + 178/1 (16,84 ha) = 41,69 ha**. ÚP přijat **2025-02-18**, EIA **STC2258** schválena.
3. **Kupující SPV**: **PPF reality 2 s.r.o. (IČO 24654744)**, založeno **2026-03-19**, jednatel **Jiří Tošek**, 100% **PPF CYPRUS RE MANAGEMENT** (HE 251908).
4. **Dluhopisový stack**: 5 prospektů, 68 tranší, **kapacita programu cca 7,6 mld. CZK** (NIKOLI cca 1 mld.). Vše křížově ručeno PROGRESUS Group a.s. Vyžadovány souhlasy CoC.
5. **Triangulace ocenění**: DCF 5,4–7,5 mld. | Pozemková komparace 2,5–5,5 mld. | Precedenty 3,3–5,2 mld. | Likvidace 1,3–3,2 mld. → **střed pro čisté aktivum 4,5 mld. CZK**.

## 5 OTÁZEK, KTERÉ PPF POLOŽÍ

1. **„Spor DANCORE?"** → Nevadská LLC #E0353972015-2, spis **30 Co 228/2019-1538** KS Praha, dvakrát zamítnuto (naposledy 2024-06-25), **odvolání podáno 2024-11-18 — STÁLE ŽIVÉ**. Navrženo specifické vynětí do úschovy.
2. **„Účetní závěrky Nový Zeleneč FY21–24?"** → Chybí, porušení §21a. **Náprava — podání před podpisem**. Pracovní verze v DR-FIN-020..024.
3. **„CoC u dluhopisového stacku?"** → Kapacita 7,6 mld. napříč 5 prospekty. Předem připravena žádost o souhlas DR-BOND-005. Proces souhlasu 60–90 dní.
4. **„130 ha vs. 42 ha?"** → k.ú. Mstětice = 135,1 ha orné půdy v 11 velkých parcelách. Předmět transakce = podmnožina 42 ha. Členění ponechané/třetí strany v DR-SCOPE-001.
5. **„Riziko klíčové osoby (Zrůst jako jediný jednatel celé vertikály)?"** → Jmenování spolujednatele před podpisem + D&O + plán pro nezpůsobilost. DR-GOV-001.

## 3 ČERVENÉ LINIE (nediskutovatelné)

1. **Žádné osobní záruky od Zrůsta ani Forala** nad rámec konkrétních zastropovaných zástav s časovými limity.
2. **Limit odškodnění 10–15 % protiplnění**; limit úschovy 12–15 % vícefondový; obecné záruky 18–24 měs., daňové/titulní 5–7 let.
3. **Minimální cena 3,7 mld. CZK**. Pod tuto hranici je refinancování-a-držení přes 6. prospekt ekonomicky výhodnější.

## 3 PÁKOVÉ BODY (co má Progresus na PPF)

1. **Symetrický požadavek na UBO / §23a**: **Jirásková (spolu-CEO PPF) ↔ Jirásko (CEO PPF banka) jsou MANŽELÉ** (HN.cz, stejná adresa Zvonická 710/3). Pokud bude úvěrovat PPF banka → §23a ZoB jako spřízněná strana. K tomu USD 1,9 mld. odkup Kellnera Jr. ze srpna 2025 přes AMALAR — zdroj prostředků není znám.
2. **Tlak nového vedení převzít odkaz**: Jirásková + Stoessel (červen 2025) zdědili dealovou tezi z éry Šmejce; pod tlakem představenstva uzavřít první vlajkový transakce kolem **4,5–5,0 mld. CZK**.
3. **Opcionalita paralelního zájemce**: Penta RE (zásoba pozemků 215 tis. m² 2023), Central Group (Žižkov 40 ha schéma), Karlín Group — všichni důvěryhodní. Udržovat zájem přes Savills/JLL nepřímo — bez porušení NDA.

## 1 KRITICKÉ RIZIKO (nutno vyřešit před podpisem)

**Placené stažení LV 927 + LV 1326 z ČÚZK** (k.ú. Mstětice 792764) potvrzující: (a) čistý titul, (b) absenci reziduálních zástav MARSEA MIA (Jana Lébrová 60 %), (c) absenci rizika zpětného vymáhání ze strany likvidátora Nuka Estates, (d) absenci nezveřejněných služebností v rozsahu 42 ha. DD rozpočet cca 50 tis. CZK, P0 tento týden. Bez tohoto jsou titulní záruky v SPA nekapitalizované.

## NOUZOVÉ KONTAKTY

| Role | Jméno | Poznámky |
|---|---|---|
| **Principál** | JUDr. Lukáš Zrůst | Strategie/právo/historie — **jediný statutární jednatel vertikály** |
| **Spoluakcionář** | Lukáš Foral | Finance/kapitálová struktura/historie PEP |
| **DD Lead** | Michal Dvořák | Provozní agenda |
| **CFO** | Ing. Petr Heyduk | Vlastník finančních dat |
| **Architekt Able** | Tomáš Korčák | Tato složka + DD pracovní prostor |
| **AI Lead Able** | Karel Duchoň | Technologická transformace |
| **KAM Able** | Václav Faraga | Komerční |
| **Interní právní (prodávající)** | Michal Pelikán | Progresus Invest Holding |
| **Externí právní (najatý)** | Vojtěch Faltus, Aegis Law | Plánovací smlouva, regulace/M&A |
| **Externí právní (druhý názor — ZADAT)** | KŠB / JŠK / White & Case | Nezávislý kontradiktorní přezkum |

## ETIKETA JEDNÁNÍ (5 zlatých pravidel)

1. **Nikdy nelhat, nezlehčovat, nehádat.** „Sladím s týmem a vrátím se k tomu" je lepší než jakýkoli odhad. Čísla jsou posvátná — každou hodnotu navázat na ID dokumentu v dataroomu.
2. **Proaktivní zveřejnění poráží reaktivní obranu.** Každý z 30 red flags musí být v dataroomu s připraveným narativem DŘÍVE, než se PPF zeptá.
3. **Jeden hlas na téma.** Zrůst = strategie/právo; Foral = finance; Dvořák = provoz; právní zástupce = formální právní pozice. Před odpověďmi přesahujícími domény se zastavit a sladit.
4. **Poslouchejte 2× více, než mluvíte.** Nezaplňujte ticho. Před odpovědí požadujte předložení odkazovaného dokumentu naživo.
5. **Mlčení je pozice.** „Vezmu to v úvahu a vrátím se [v čase]" je nesrovnatelně lepší než ukvapená odpověď, která vytvoří prohlášení a záruky expozici.

---

*Podkladový list — tisk A4 jednostranně. Nahrazuje všechny předchozí one-pagery. Plný kontext: MASTER-DD-REPORT-v1.0 + PPF-PLAYBOOK v2.0 + VALUATION-DEFENSE-MEMO + RED-FLAGS.*

<!-- BACKLINKS_START -->

---

## 🔗 Zpětné odkazy

Na tento soubor odkazují:

- [MISSION-COMPLETE.md](./MISSION-COMPLETE.md) — `EXECUTIVE-ONE-PAGER.md`

## 🏷️ Související soubory (podle shody tagů)

*Žádné silně související soubory (shoda tagů pod prahem 0,3).*

## 🌐 Pohled grafu

[Otevřít v portálu](./index.html) · [Mapa stránek](./sitemap.html) · [Hledat](./search.html) · Focus ID: `EXECUTIVE-ONE-PAGER.md`

---
*Automaticky vygenerováno skriptem `_assets/build-backlinks.py` · 2026-04-21*
<!-- BACKLINKS_END -->
