# Přehled ČERVENÝCH PRAPORŮ — DD Progresus → PPF

**Poslední aktualizace**: 2026-04-21 (Pass 4 — autoritativní ČÚZK / Sbírka listin / ISIR / dossiery)
**Celkem red flags**: 18 KRITICKÝCH + 12 VYSOKÝCH + 6 VYŘEŠENÝCH / DEGRADOVANÝCH

---

## 🟢 VYŘEŠENO / DEGRADOVÁNO (6)

| # | Předchozí zjištění | Vyřešení | Zdroj |
|---|---------------|------------|--------|
| ✓ C1 (dříve RF-6→26) | CASPER 800M/229M | **Casper Group (Štekl)** externí spoluinvestor na Vitrablok; 800M = celkem, 229M = Progresus | Pass 2–4 |
| ✓ C4 | DANCORE 209,6M | **DANCORE LLC Nevada** — 6letý spor o NZ pozemky (nyní RF-26 KRITICKÉ) | Pass 4 ISIR agent |
| ✓ C5 | 4 řízení jako 1 | = sériové spory DANCORE (jedna protistrana, několik kol) | Pass 4 |
| ↓ RF-6 | Historická insolvence RD Rýmařov | Návrh z 2009 zamítnut do 3 dnů jako „nesmyslný" — NENÍ SUBSTANTIVNÍ | Pass 4 |
| ↓ RF-16 | Čínská zeď Zrůsta | **Žádný přímý konflikt ve veřejných záznamech** (ZOOT/VHM/Sberbank/Amati ≠ aktiva Progresus); architektonická obava trvá | Pass 4 |
| ✓ C2 | RONDAX skrytý | Nenalezen v ARES — **pravděpodobně OCR chyba** v dokumentech 2026-04-01 | Vyčerpávající hledání |

---

## 🔴 KRITICKÉ (18)

### RF-1: Spor o vlastnictví zástavy dluhopisů (Pro Věřitele)
Tvrzení, že zastavená nemovitost „pravděpodobně není ve vlastnictví emitenta". **Ověřit přes ČÚZK + dluhopisová indentura.**

### RF-2: Procesní integrita zelenečského územního plánu
Petice se 138 podpisy (2022) tvrdí „nepatřičné vazby mezi zástupcem plánu a projektantem".

### RF-3: Pozdní zveřejnění finančních výsledků Progresus
(Nyní rozšířeno na RF-27: **Nový Zeleneč a.s. FY2021–2024 vše chybí, 4letá prodleva**)

### RF-4: Agresivní taktiky retailového prodeje dluhopisů
newstream.cz + proveritele.cz: nátlakové oslovování, intenzivní kampaně.

### RF-5: Duální vlastnictví pozemků (Nový Zeleneč a.s. + RD Rýmařov Invest III. alpha s.r.o.)
Nyní známá IČO: 27825981 + **10800123** (založeno 2021-04-30, Karlín). Ve skutečnosti vnitřně naskládáno (III.alpha vlastní NZ a.s.).

### RF-8: HP (Hospodářské Pozemky?) zákaz sdílení
Nevyřešeno — třeba znovu načíst zdrojový dokument.

### RF-9: Quinlan Private — distresový původ pozemků
42 ha přes zkrachovalý irský PE → Nuka Estates Luxembourg → Lébr → Progresus.

### RF-10: Nuka Estates s.r.o. stále v likvidaci
(IČO 27890104; likvidátor Pavlína Zdařilová od 2023-04-19; **adresa opravena na Holická 1173/49a Hodolany**)

### RF-11: Status zajištěného věřitele MARSEA MIA
**Stále AKTIVNÍ — zástavy mohou nadále zatěžovat 130ha pool**. Vazba na rodinu Lébr (Jana Lébrová 60 %).

### RF-12: Reziduální vztah Lébr / Ravantino Group
Web stále inzeruje projekt. Vyžadován formální dopis.

### RF-13: Rozsah 130 ha vs. 42 ha
**Ověřeno**: k.ú. Mstětice (**792764**) = 135,1 ha orné půdy. Kandidát na transakce = 73/1 (24,85 ha) + 178/1 (16,84 ha) = 41,7 ha ≈ 42 ha.

### RF-14: Reorganizace skupiny 2023-04 → 2024-01 (strana Progresus)
Restrukturalizováno 9 dceřiných společností. Načasování podezřelé vůči transakci.

### RF-26: DANCORE LLC — 6letý spor s vazbou na USA o NZ pozemky [NOVÉ / ROZŠÍŘENÉ 2026-04-21]
- Nevadská LLC #E0353972015-2, založena **2015-07-23**, Las Vegas
- Spis 30 Co 228/2019-1538 Krajský soud Praha (1 538 dokumentů = velmi rozsáhlý spis)
- Dvakrát zamítnuto (naposledy 2024-06-25)
- **Odvolání podáno 2024-11-18 STÁLE ŽIVÉ**
- **V dluhopisovém prospektu zavádějícně zveřejněno jako „jeden spor"**
- Charakterizace Progresus: „zahraniční společnost bez aktiv s nejasnou vlastnickou strukturou"
- **NOVÉ ZJIŠTĚNÍ**: **Dancore LLC v. Zika, 2:18-cv-01136 (D. Nev. 2018)** — samostatný americký federální spor NEZVEŘEJNĚN v žádném dokumentu Progresus. „Zika" je české příjmení → hypotéza o vlastnictví v diaspoře
- **NOVÉ ZJIŠTĚNÍ**: Profil Zrůsta jako insolvenčního správce → obrana §984 dobrověrného nabyvatele má expozici nedobré víry, je-li uplatněn standard „skutečné vědomosti"
- **Očekávaná expozice: vážená CZK 102,5M / doporučená úschova CZK 250–400M / nepravděpodobná škoda CZK 1,0 mld.**
- **Plná forenzní složka**: `04-legal/DANCORE-FORENSIC-DOSSIER.md` (466 řádků, 10 sekcí)

### RF-27: Nový Zeleneč a.s. — 4letá prodleva v podání účetních závěrek [NOVÉ]
- NULA podání za FY2021, 2022, 2023, 2024
- Pouze FY2020 ve spisu
- **Porušuje §21a zákona o účetnictví**
- PPF nemůže ocenit bez reálných financí

### RF-28: Soubor dluhopisů je 7,6+ mld. CZK (ne ~1 mld.) [NOVÉ]
- 5 schválených prospektů, 68 tranší
- 4/5 emitentů má NULU finančních podání
- 5. prospekt schválen 2026-01-28 v průběhu jednání s PPF
- Agregátní expozice CoC výrazně vyšší

### RF-29: Operativní koncentrace u Zrůsta [NOVÉ]
- **Jediný jednatel celé dealové vertikály**: NZ a.s. + RD Rýmařov III.alpha + PROGRESUS Developments + PROGRESUS Bonds
- Jediná nezpůsobilost = provozní kolaps

### RF-30: Jirásková + Jirásko POTVRZENI jako manželé (konflikt na straně PPF) [NOVÉ]
- Potvrzeno přes HN.cz
- Oba povýšeni Kellnerem 2013
- **Financování PPF banka = území §23a ZoB jako spřízněná strana**
- Akce: vyžadovat třetí stranu jako banku NEBO clearance dopis §23a od ČNB

### RF-31: AMALAR 100% vlastnictví PPF + odkup Kellnera Jr. za USD 1,9 mld. [NOVÉ]
- Srpen 2025: Kellnerová + 3 dcery odkoupily 10% podíl Petra Kellnera Jr. za **USD 1,9 MILIARDY**
- Zdroj prostředků NEZNÁMÝ
- Mohl by jít o úvěr od PPF banka → znásobené riziko spřízněné strany
- AMALAR Czech s.r.o., nikoli zahraniční vehikl (zjednodušené, ale dohledatelné)

---

## 🟠 VYSOKÉ (12)

### RF-15: Financování akvizice RD Rýmařov 2020 ze strany rodiny SIKO / Valový
### RF-16: Vzor akvizic z insolvencí (Zrůst/Konreo/Casper/Progresus) — architektonický
### RF-17: RD Rýmařov s.r.o. jako věřitel ve 3 aktivních insolvencích
### RF-18: Nevysvětlená duální entita Progresus „core" a.s.
### RF-19: První územní plán Zeleneč až z 02/2025
### RF-20: Komplexita 100+ entit skupiny
### RF-21: Neobvyklý mix oborů (doplňky stravy, právo, IT)
### RF-22: Nový Zeleneč a.s. registrován v Olomouci (odkaz Lébr)
### RF-23: Více entit „Acquisitions" z restrukturalizace 2023
### RF-24: Více podobně pojmenovaných entit „Developments"
### RF-25: Přístup k registru UBO omezen 12/2025

### RF-32: Redomicil PPF NL→CZ 2026-04-01 [NOVÉ]
- Trvalá strukturální událost, není specifická pro transakci
- Časově se kryje s reorganizací představenstva
- **Páka**: éra nového spolu-CEO (Jirásková + Stoessel) zdědila tezi transakce po Šmejcovi

### RF-33: Robert Ševela mnohem výše postavený, než předchozí intel naznačoval [NOVÉ]
- 20letý vrchní investiční ředitel PPF
- 115 propojených společností, CZK 14 mld. státních zakázek
- **Operátor PPF s nejvyšší pákou**
- Uzavření transakce vyžaduje jeho souhlas

### RF-34: Expozice Frydrycha Rusko/Eldorado [NOVÉ]
- **CEO ruského Eldoradu 2014–2016**
- Vyžadována postsankční prověrka

### RF-35: Menno Verhoeff — další signatář představenstva PPF [NOVÉ]
- Holanďan, ex-CBRE, vede PPF RE NL+UK
- Nastoupil do představenstva PPF Group v květnu 2025

### RF-36: Aleš Minx (bývalý předseda představenstva PPF → poradce AMALAR) [NOVÉ]
- Historický nositel teze transakce se Šmejcem
- Nyní v AMALAR (rodinné poradenství)

---

## Souhrn

- **KRITICKÉ**: 18 (6 NOVÝCH v Pass 4)
- **VYSOKÉ**: 12 (5 NOVÝCH v Pass 4)
- **VYŘEŠENO/DEGRADOVÁNO**: 6
- **Celkem aktivních flagů**: 30

**Agregátní tlak na ocenění**: **−18 až −33 %**, pokud zjištění zasáhnou PPF v rámci DD bez přípravy prodávajícího.

**Připravenost po Pass 4**: 55 % (z 25 % před Pass 4)
**Cíl pro první jednání s PPF**: 90 %+

<!-- BACKLINKS_START -->

---

## 🔗 Zpětné odkazy

Na tento soubor odkazují:

- [02-entity/raw-cuzk/README.md](./02-entity/raw-cuzk/README.md) — `../../RED-FLAGS.md` (2×)
- [05-osint/ppf-side-deep/README.md](./05-osint/ppf-side-deep/README.md) — `../../RED-FLAGS.md` (2×)
- [06-reports/red-flags-dashboard.html](./06-reports/red-flags-dashboard.html) — RED-FLAGS.md (2×)
- [06-reports/monte-carlo-valuation.html](./06-reports/monte-carlo-valuation.html) — Rizikové signály
- [06-reports/pressure-radar.html](./06-reports/pressure-radar.html) — RED-FLAGS.md
- [06-reports/valuation-calculator.html](./06-reports/valuation-calculator.html) — Rizikové signály
- [08-comms-templates/comms-hub.html](./08-comms-templates/comms-hub.html) — Red flags
- [BACKLINKS-AUDIT.md](./BACKLINKS-AUDIT.md) — RED-FLAGS.md

## 🏷️ Související soubory (podle shody tagů)

*Žádné silně související soubory (shoda tagů pod prahem 0,3).*

## 🌐 Pohled grafu

[Otevřít v portálu](./index.html) · [Mapa stránek](./sitemap.html) · [Hledat](./search.html) · Focus ID: `RED-FLAGS.md`

---
*Automaticky vygenerováno skriptem `_assets/build-backlinks.py` · 2026-04-21*
<!-- BACKLINKS_END -->
