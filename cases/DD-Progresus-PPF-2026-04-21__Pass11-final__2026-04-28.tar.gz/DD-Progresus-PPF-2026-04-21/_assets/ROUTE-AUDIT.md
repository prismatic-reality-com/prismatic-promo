# Audit odkazů — 2026-04-21

Automaticky vygenerováno skriptem `_assets/test-routes.py`. Spusťte znovu pro obnovení.

## Shrnutí

- Zkontrolováno HTML: **38**
- Lokálních odkazů celkem: **2610**
- Rozbitých odkazů: **88**

## Rozbité odkazy (k řešení)

- `01-intel/ppf-governance.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#"` — soubor nenalezen (řádek 166, vyřešeno na `01-intel/ppf-people-dossiers.md#`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#lukáš-zrůst"` — soubor nenalezen (řádek 309, vyřešeno na `01-intel/principals-deep-osint.md#lukáš-zrůst`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#lukáš-foral"` — soubor nenalezen (řádek 317, vyřešeno na `01-intel/principals-deep-osint.md#lukáš-foral`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#josef-lébr"` — soubor nenalezen (řádek 358, vyřešeno na `01-intel/principals-deep-osint.md#josef-lébr`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#kateřina-jirásková"` — soubor nenalezen (řádek 367, vyřešeno na `01-intel/ppf-people-dossiers.md#kateřina-jirásková`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#didier-stoessel"` — soubor nenalezen (řádek 375, vyřešeno na `01-intel/ppf-people-dossiers.md#didier-stoessel`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#ondřej-frydrych"` — soubor nenalezen (řádek 383, vyřešeno na `01-intel/ppf-people-dossiers.md#ondřej-frydrych`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#jiří-tošek"` — soubor nenalezen (řádek 390, vyřešeno na `01-intel/ppf-people-dossiers.md#jiří-tošek`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#robert-ševela"` — soubor nenalezen (řádek 398, vyřešeno na `01-intel/ppf-people-dossiers.md#robert-ševela`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#menno-verhoeff"` — soubor nenalezen (řádek 405, vyřešeno na `01-intel/ppf-people-dossiers.md#menno-verhoeff`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#aleš-minx"` — soubor nenalezen (řádek 412, vyřešeno na `01-intel/ppf-people-dossiers.md#aleš-minx`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#renáta-kellnerová"` — soubor nenalezen (řádek 419, vyřešeno na `01-intel/ppf-people-dossiers.md#renáta-kellnerová`)
- `01-intel/stakeholder-map.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#petr-jirásko"` — soubor nenalezen (řádek 426, vyřešeno na `01-intel/ppf-people-dossiers.md#petr-jirásko`)
- `02-entity/geo-parcel-map.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-11"` — soubor nenalezen (řádek 339, vyřešeno na `RED-FLAGS.md#rf-11`)
- `02-entity/parcel-map.html` → `?file=="reader.html?file=02-entity/cuzk-cadastre-forensics.md#3-schéma-130-ha--kandidátní-parcely"` — soubor nenalezen (řádek 230, vyřešeno na `02-entity/cuzk-cadastre-forensics.md#3-schéma-130-ha--kandidátní-parcely`)
- `02-entity/parcel-map.html` → `?file=="reader.html?file=02-entity/land-title-chain.md#q3--rozsah-130-ha-vs-42-ha"` — soubor nenalezen (řádek 231, vyřešeno na `02-entity/land-title-chain.md#q3--rozsah-130-ha-vs-42-ha`)
- `02-entity/parcel-map.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-11"` — soubor nenalezen (řádek 233, vyřešeno na `RED-FLAGS.md#rf-11`)
- `02-entity/parcel-map.html` → `?file=="reader.html?file=02-entity/cuzk-cadastre-forensics.md#7-vyrovnání-130-ha-vs-42-ha"` — soubor nenalezen (řádek 236, vyřešeno na `02-entity/cuzk-cadastre-forensics.md#7-vyrovnání-130-ha-vs-42-ha`)
- `02-entity/parcel-map.html` → `?file=="reader.html?file=02-entity/cuzk-cadastre-forensics.md#3-schéma-130-ha--kandidátní-parcely"` — soubor nenalezen (řádek 237, vyřešeno na `02-entity/cuzk-cadastre-forensics.md#3-schéma-130-ha--kandidátní-parcely`)
- `03-financial/bond-stack.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 74, vyřešeno na `RED-FLAGS.md#rf-28`)
- `03-financial/bond-stack.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 108, vyřešeno na `RED-FLAGS.md#rf-28`)
- `03-financial/bond-stack.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 267, vyřešeno na `RED-FLAGS.md#rf-28`)
- `03-financial/bond-stack.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 312, vyřešeno na `RED-FLAGS.md#rf-28`)
- `03-financial/tax-calculator.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-27"` — soubor nenalezen (řádek 150, vyřešeno na `RED-FLAGS.md#rf-27`)
- `04-legal/dancore-timeline.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-26"` — soubor nenalezen (řádek 74, vyřešeno na `RED-FLAGS.md#rf-26`)
- `04-legal/dancore-timeline.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-26"` — soubor nenalezen (řádek 217, vyřešeno na `RED-FLAGS.md#rf-26`)
- `04-legal/dancore-timeline.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-26"` — soubor nenalezen (řádek 240, vyřešeno na `RED-FLAGS.md#rf-26`)
- `06-reports/red-flags-dashboard.html` → `?file=="reader.html?file=RED-FLAGS.md#"` — soubor nenalezen (řádek 287, vyřešeno na `RED-FLAGS.md#`)
- `06-reports/red-flags-dashboard.html` → `?file=="reader.html?file=RED-FLAGS.md#"` — soubor nenalezen (řádek 346, vyřešeno na `RED-FLAGS.md#`)
- `06-reports/roadmap-gantt.html` → `?file=="reader.html?file=06-reports/MASTER-ACTION-PLAN.md#"` — soubor nenalezen (řádek 157, vyřešeno na `06-reports/MASTER-ACTION-PLAN.md#`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-26"` — soubor nenalezen (řádek 232, vyřešeno na `RED-FLAGS.md#rf-26`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-27"` — soubor nenalezen (řádek 238, vyřešeno na `RED-FLAGS.md#rf-27`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 244, vyřešeno na `RED-FLAGS.md#rf-28`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-29"` — soubor nenalezen (řádek 250, vyřešeno na `RED-FLAGS.md#rf-29`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-30"` — soubor nenalezen (řádek 256, vyřešeno na `RED-FLAGS.md#rf-30`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-31"` — soubor nenalezen (řádek 262, vyřešeno na `RED-FLAGS.md#rf-31`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-11"` — soubor nenalezen (řádek 268, vyřešeno na `RED-FLAGS.md#rf-11`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-10"` — soubor nenalezen (řádek 274, vyřešeno na `RED-FLAGS.md#rf-10`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-2"` — soubor nenalezen (řádek 280, vyřešeno na `RED-FLAGS.md#rf-2`)
- `executive-briefing.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-1"` — soubor nenalezen (řádek 286, vyřešeno na `RED-FLAGS.md#rf-1`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#lukas-zrust"` — soubor nenalezen (řádek 506, vyřešeno na `01-intel/principals-deep-osint.md#lukas-zrust`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#lukas-foral"` — soubor nenalezen (řádek 507, vyřešeno na `01-intel/principals-deep-osint.md#lukas-foral`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#michal-dvorak"` — soubor nenalezen (řádek 508, vyřešeno na `01-intel/principals-deep-osint.md#michal-dvorak`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#petr-heyduk"` — soubor nenalezen (řádek 509, vyřešeno na `01-intel/principals-deep-osint.md#petr-heyduk`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#michal-pelikan"` — soubor nenalezen (řádek 510, vyřešeno na `01-intel/principals-deep-osint.md#michal-pelikan`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#jiri-tosek"` — soubor nenalezen (řádek 539, vyřešeno na `01-intel/ppf-people-dossiers.md#jiri-tosek`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#robert-sevela"` — soubor nenalezen (řádek 540, vyřešeno na `01-intel/ppf-people-dossiers.md#robert-sevela`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#katerina-jiraskova"` — soubor nenalezen (řádek 541, vyřešeno na `01-intel/ppf-people-dossiers.md#katerina-jiraskova`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#didier-stoessel"` — soubor nenalezen (řádek 542, vyřešeno na `01-intel/ppf-people-dossiers.md#didier-stoessel`)
- `executive-briefing.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#menno-verhoeff"` — soubor nenalezen (řádek 543, vyřešeno na `01-intel/ppf-people-dossiers.md#menno-verhoeff`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-26"` — soubor nenalezen (řádek 254, vyřešeno na `RED-FLAGS.md#rf-26`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-27"` — soubor nenalezen (řádek 255, vyřešeno na `RED-FLAGS.md#rf-27`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 256, vyřešeno na `RED-FLAGS.md#rf-28`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-30"` — soubor nenalezen (řádek 257, vyřešeno na `RED-FLAGS.md#rf-30`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-31"` — soubor nenalezen (řádek 258, vyřešeno na `RED-FLAGS.md#rf-31`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-33"` — soubor nenalezen (řádek 259, vyřešeno na `RED-FLAGS.md#rf-33`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-34"` — soubor nenalezen (řádek 260, vyřešeno na `RED-FLAGS.md#rf-34`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-32"` — soubor nenalezen (řádek 261, vyřešeno na `RED-FLAGS.md#rf-32`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-11"` — soubor nenalezen (řádek 262, vyřešeno na `RED-FLAGS.md#rf-11`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-29"` — soubor nenalezen (řádek 263, vyřešeno na `RED-FLAGS.md#rf-29`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-26"` — soubor nenalezen (řádek 267, vyřešeno na `RED-FLAGS.md#rf-26`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-27"` — soubor nenalezen (řádek 268, vyřešeno na `RED-FLAGS.md#rf-27`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 269, vyřešeno na `RED-FLAGS.md#rf-28`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-30"` — soubor nenalezen (řádek 270, vyřešeno na `RED-FLAGS.md#rf-30`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-31"` — soubor nenalezen (řádek 271, vyřešeno na `RED-FLAGS.md#rf-31`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-33"` — soubor nenalezen (řádek 272, vyřešeno na `RED-FLAGS.md#rf-33`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-34"` — soubor nenalezen (řádek 273, vyřešeno na `RED-FLAGS.md#rf-34`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-32"` — soubor nenalezen (řádek 274, vyřešeno na `RED-FLAGS.md#rf-32`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-11"` — soubor nenalezen (řádek 275, vyřešeno na `RED-FLAGS.md#rf-11`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-29"` — soubor nenalezen (řádek 276, vyřešeno na `RED-FLAGS.md#rf-29`)
- `index.html` → `?file=="reader.html?file=RED-FLAGS.md#rf-28"` — soubor nenalezen (řádek 383, vyřešeno na `RED-FLAGS.md#rf-28`)
- `index.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#lukas-zrust"` — soubor nenalezen (řádek 1028, vyřešeno na `01-intel/principals-deep-osint.md#lukas-zrust`)
- `index.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#lukas-foral"` — soubor nenalezen (řádek 1037, vyřešeno na `01-intel/principals-deep-osint.md#lukas-foral`)
- `index.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#michal-dvorak"` — soubor nenalezen (řádek 1046, vyřešeno na `01-intel/principals-deep-osint.md#michal-dvorak`)
- `index.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#petr-heyduk"` — soubor nenalezen (řádek 1055, vyřešeno na `01-intel/principals-deep-osint.md#petr-heyduk`)
- `index.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#tomas-korcak"` — soubor nenalezen (řádek 1064, vyřešeno na `01-intel/principals-deep-osint.md#tomas-korcak`)
- `index.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#karel-duchon"` — soubor nenalezen (řádek 1073, vyřešeno na `01-intel/principals-deep-osint.md#karel-duchon`)
- `index.html` → `?file=="reader.html?file=01-intel/principals-deep-osint.md#vaclav-faraga"` — soubor nenalezen (řádek 1082, vyřešeno na `01-intel/principals-deep-osint.md#vaclav-faraga`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#katerina-jiraskova"` — soubor nenalezen (řádek 1101, vyřešeno na `01-intel/ppf-people-dossiers.md#katerina-jiraskova`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#didier-stoessel"` — soubor nenalezen (řádek 1110, vyřešeno na `01-intel/ppf-people-dossiers.md#didier-stoessel`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#robert-sevela"` — soubor nenalezen (řádek 1119, vyřešeno na `01-intel/ppf-people-dossiers.md#robert-sevela`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#pavel-frydrych"` — soubor nenalezen (řádek 1128, vyřešeno na `01-intel/ppf-people-dossiers.md#pavel-frydrych`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#jiri-tosek"` — soubor nenalezen (řádek 1137, vyřešeno na `01-intel/ppf-people-dossiers.md#jiri-tosek`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#menno-verhoeff"` — soubor nenalezen (řádek 1146, vyřešeno na `01-intel/ppf-people-dossiers.md#menno-verhoeff`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#ales-minx"` — soubor nenalezen (řádek 1155, vyřešeno na `01-intel/ppf-people-dossiers.md#ales-minx`)
- `index.html` → `?file=="reader.html?file=01-intel/ppf-people-dossiers.md#renata-kellnerova"` — soubor nenalezen (řádek 1164, vyřešeno na `01-intel/ppf-people-dossiers.md#renata-kellnerova`)
- `reader.html` → `?file=="reader.html?file=RED-FLAGS.md#"` — soubor nenalezen (řádek 618, vyřešeno na `RED-FLAGS.md#`)
- `reader.html` → `?file=="reader.html?file=…"` — soubor nenalezen (řádek 768, vyřešeno na `…`)

## Rozpis po souborech

| Soubor | Celkem | OK | Rozbité | Přeskočeno |
|---|---:|---:|---:|---:|
| `01-intel/ppf-governance.html` | 102 | 101 | 1 | 0 |
| `01-intel/stakeholder-map.html` | 100 | 88 | 12 | 0 |
| `02-entity/entity-graph.html` | 76 | 76 | 0 | 0 |
| `02-entity/entity-offices-map.html` | 86 | 86 | 0 | 0 |
| `02-entity/geo-parcel-map.html` | 98 | 97 | 1 | 0 |
| `02-entity/parcel-map.html` | 95 | 90 | 5 | 0 |
| `03-financial/bond-stack.html` | 105 | 101 | 4 | 0 |
| `03-financial/tax-calculator.html` | 120 | 119 | 1 | 0 |
| `04-legal/dancore-timeline.html` | 99 | 96 | 3 | 0 |
| `06-reports/deal-journey.html` | 86 | 86 | 0 | 0 |
| `06-reports/geo-deal-overview.html` | 85 | 85 | 0 | 0 |
| `06-reports/live-ticker.html` | 18 | 18 | 0 | 0 |
| `06-reports/monte-carlo-valuation.html` | 63 | 63 | 0 | 0 |
| `06-reports/pressure-radar.html` | 76 | 76 | 0 | 0 |
| `06-reports/red-flags-dashboard.html` | 48 | 46 | 2 | 0 |
| `06-reports/relationships-matrix.html` | 39 | 39 | 0 | 0 |
| `06-reports/roadmap-gantt.html` | 67 | 66 | 1 | 0 |
| `06-reports/scenario-compare.html` | 23 | 23 | 0 | 0 |
| `06-reports/valuation-calculator.html` | 123 | 123 | 0 | 0 |
| `08-comms-templates/comms-hub.html` | 67 | 67 | 0 | 0 |
| `executive-briefing.html` | 250 | 230 | 20 | 0 |
| `export-pack.html` | 30 | 30 | 0 | 0 |
| `index.html` | 375 | 339 | 36 | 0 |
| `keyboard-help.html` | 28 | 28 | 0 | 0 |
| `knowledge-graph.html` | 66 | 66 | 0 | 0 |
| `md-index.html` | 57 | 57 | 0 | 0 |
| `print-pack.html` | 17 | 17 | 0 | 0 |
| `reader.html` | 35 | 33 | 2 | 0 |
| `rendered/all-in-one.html` | 0 | 0 | 0 | 0 |
| `rendered/index.html` | 6 | 6 | 0 | 0 |
| `rendered/master-report.html` | 4 | 4 | 0 | 0 |
| `rendered/one-pager.html` | 4 | 4 | 0 | 0 |
| `rendered/playbook.html` | 4 | 4 | 0 | 0 |
| `rendered/red-flags.html` | 5 | 5 | 0 | 0 |
| `rendered/valuation.html` | 5 | 5 | 0 | 0 |
| `search.html` | 67 | 67 | 0 | 0 |
| `sitemap.html` | 69 | 69 | 0 | 0 |
| `test-all.html` | 12 | 12 | 0 | 0 |
